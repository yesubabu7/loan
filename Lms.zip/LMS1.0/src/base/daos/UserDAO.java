package base.daos;

public class UserDAO {

}
